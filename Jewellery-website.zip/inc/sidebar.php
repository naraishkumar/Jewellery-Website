<div class="text">
      <h1>Best Jewellery<br />Collection</h1>
      <p>
        It is a long fact that a reader will be distracted by the readable
        content of the page when looking at its Lorem ipsum dolor sit amet,
        consectetur adipisicing elit. Beatae, eos?
      </p>
      <button>Shop Now</button>
</div>