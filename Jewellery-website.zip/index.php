<!-- HEADER -->

<?php include 'inc/header/header.php'; ?>
</div>

<!-- SIDEBAR -->
<?php include 'inc/sidebar.php' ?>
</div>

<!-- LATEST PRODUCTS -->
<?php include 'card.php'; ?>

<!-- ABOUT US -->
<?php include 'about-us.php'; ?>

<!-- LATEST FROM DISCOUNT -->
<?php include 'discount.php'; ?>

<!-- LATEST FROM BLOG -->
<?php include 'blog.php'; ?>

<!-- TESTIMONIAL -->
<?php include 'testominal.php';?>

<!-- FOOTER -->
<?php include 'inc/footer/footer.php'; ?>