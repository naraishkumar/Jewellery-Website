<?php
include 'includes/header/header.php';

$tbl_name = 'tbl_site_settings';
delete_record($tbl_name);

?>