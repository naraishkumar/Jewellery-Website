<?php 

include 'includes/header/header.php';

include 'includes/header/sidebar.php';

include 'content/content.php';

include 'includes/footer/footer.php';

?>
