<!-- side bar -->
<div class="main-container">
    <div class="navcontainer">
        <nav class="nav">
            <div class="nav-upper-options">
                <div class="nav-option option1">
                    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210182148/Untitled-design-(29).png" class="nav-img" alt="dashboard" style="width:35px; border-radius:50%;">
                    <h5><a href="/Jewellery-website/admin/index.php" style="text-decoration: none; color:white;">Dashboard</a></h5>
                </div>

                

                <div class="nav-option option3">
                    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210183320/5.png" class="nav-img" alt="report" style="width:25px; border-radius:50%;">
                    <h5><a href="/Jewellery-website/admin/users.php" style="text-decoration: none; color:black;">Users</a></h5>
                </div>
                <div class="nav-option option3">
                    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210183320/5.png" class="nav-img" alt="report" style="width:25px; border-radius:50%;">
                    <h5><a href="/Jewellery-website/admin/products/products.php" style="text-decoration: none; color:black;">Products</a></h5>
                </div>
                <div class="nav-option option3">
                    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210183320/5.png" class="nav-img" alt="report" style="width:25px; border-radius:50%;">
                    <h5><a href="/Jewellery-website/admin/orders.php" style="text-decoration: none; color:black;">Orders</a></h5>
                </div>
                <div class="nav-option option3">
                    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210183320/5.png" class="nav-img" alt="report" style="width:25px; border-radius:50%;">
                    <h5><a href="/Jewellery-website/admin/invoices.php" style="text-decoration: none; color:black;">Invoices</a></h5>
                </div>
                <div class="nav-option option5">
                    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210183323/10.png" class="nav-img" alt="blog" style="width:25px; border-radius:50%;">
                    <h5> Profile</h5>
                </div>

                <div class="nav-option option6">
                    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210183320/4.png" class="nav-img" alt="settings" style="width:25px; border-radius:50%;">
                    <h5><a href="/Jewellery-website/admin/settings.php" style="text-decoration: none; color:black;">Settings</a></h5>
                </div>

                <div class="nav-option logout">
                    <img src="https://media.geeksforgeeks.org/wp-content/uploads/20221210183321/7.png" class="nav-img" alt="logout" style="width:25px; border-radius:50%;">
                    <h5><a href="/Jewellery-website/admin/logout.php" style="text-decoration: none; color:black;">Logout</a></h5>
                </div>

            </div>
        </nav>
    </div>