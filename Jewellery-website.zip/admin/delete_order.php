<?php
include 'includes/header/header.php';

$tbl_name = 'tbl_orders';
delete_record($tbl_name);

?>