<?php
include 'includes/header/header.php';

$tbl_name = 'tbl_products';
delete_record($tbl_name);

?>