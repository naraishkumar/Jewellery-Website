<!-- LATEST FROM BLOG -->
<section class="blog">
    <h2>LATEST FROM BLOG</h2>
    <div class="blog-row">
      <div class="blog-col-1">
        <img src="assets/images/latest from blog/blog-pic.png" alt="">
        <div class="blog-text">
          <h3>Molestiae ad reiciendis dignissimos</h3>
          <p><span>alteration in some form, by injected humour, or randomised words which don't look even slightly
              believable</span></p>
          <div class="readmore"><a href="#View All Products">Read More</a></div>
        </div>
      </div>
      <div class="blog-col-2">
        <img src="assets/images/latest from blog/blog-pic2.png " alt="">
        <div class="blog-text">
          <h3>Molestiae ad reiciendis dignissimos</h3>
          <p><span>alteration in some form, by injected humour, or randomised words which don't look even slightly
              believable</span></p>
          <div class="readmore"><a href="#View All Products">Read More</a></div>
        </div>
      </div>
    </div>
  </section>