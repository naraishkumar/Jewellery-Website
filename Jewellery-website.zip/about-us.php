<section class="about-us" id="about-us">
    <div class="row">
      <div class="col-1">
        <img src="assets/images/about-us/about.jpg" alt="">
      </div>
      <div class="col-2">
        <div class="text2">
          <h2>ABOUT US</h2>
          <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed modi laboriosam deleniti. Laboriosam vel nisi
            dolor numquam nihil iste aliquam, labore officia autem tempora consequatur excepturi id ex repellat facere
            illum dolorem repellendus placeat nostrum. Excepturi possimus suscipit hic nisi!</p>
          <div class="vlp2"><a href="#View All Products">Read More</a></div>
        </div>
      </div>
    </div>
  </section>